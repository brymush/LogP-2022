﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppCalculadora
{
    public partial class FrmCalculadora : Form
    {
        public FrmCalculadora()
        {
            InitializeComponent();
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            float varNum1 = float.Parse(txtNum1.Text);
            float varNum2 = float.Parse(txtNum2.Text);
            float varResultado;

            //Soma:

            varResultado = (varNum1 + varNum2);
            MessageBox.Show("O resultado da soma é: " + varResultado);
        }

        private void btnSubtracao_Click(object sender, EventArgs e)
        {
            float varNum1 = float.Parse(txtNum1.Text);
            float varNum2 = float.Parse(txtNum2.Text);
            float varResultado;

            //Subtração:

            varResultado = (varNum1 - varNum2);
            MessageBox.Show("O resultado da subtração é: " + varResultado);
        }

        private void btnDivisao_Click(object sender, EventArgs e)
        {
            float varNum1 = float.Parse(txtNum1.Text);
            float varNum2 = float.Parse(txtNum2.Text);
            float varResultado;

            //Divisão:

            varResultado = (varNum1 / varNum2);
            MessageBox.Show("O resultado da divisão é: " + varResultado);
        }

        private void btnMultiplicacao_Click(object sender, EventArgs e)
        {
            float varNum1 = float.Parse(txtNum1.Text);
            float varNum2 = float.Parse(txtNum2.Text);
            float varResultado;

            //Multiplicação:

            varResultado = (varNum1*varNum2);
            MessageBox.Show("O resultado da multiplicação é: " + varResultado);
        }
    }
}
